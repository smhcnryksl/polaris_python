sayi = int(input("Geriye saymak istediğiniz sayıyı giriniz: "))

for i in range(sayi, 0, -1):
    print(i)

print("Ateşle!")
