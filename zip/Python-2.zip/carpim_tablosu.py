for i in range(9):
    sayi_1 = i + 1
    for n in range(9):
        sayi_2 = n + 1
        carpim = sayi_1 * sayi_2
        print(f"{n + 1} x {i + 1} = {carpim}", end = "  ")
    print()

