sayi = int(input("Hesaplamak istediğiniz sayıyı giriniz: "))
hesaplama = int(sayi * (sayi + 1) / 2)

print(f"1'den {sayi} sayısına kadar olan sayıların toplamı: {hesaplama}")
