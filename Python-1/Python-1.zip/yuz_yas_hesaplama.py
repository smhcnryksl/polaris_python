name = input("İsmin nedir? ").capitalize()
age = int(input("Kaç yaşındasın? "))

print(f"Merhaba, {name}. {2025 - age + 100} yılında 100 yaşına gireceksin.")