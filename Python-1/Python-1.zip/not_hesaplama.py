alinan_not = float(input("Notunuzu girin: "))

if alinan_not > 50:
    print("Geçti")
else:
    print("Kaldı")